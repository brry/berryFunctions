library(testthat)
library(dwdradar)

test_check("dwdradar")
