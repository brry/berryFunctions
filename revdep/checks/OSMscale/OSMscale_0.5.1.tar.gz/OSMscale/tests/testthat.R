library(testthat)
library(OSMscale)

test_check("OSMscale")
