library(testthat)
library(extremeStat)

test_check("extremeStat")
